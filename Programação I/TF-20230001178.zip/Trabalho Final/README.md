# Superclasse: Item

Subclasses: Food,  Weapon, Potion

# Interface: Consumable

Implements: Food, Potion



O domínio do problema é a implementação de um sistema de transferência, armazenamento e alteração de objetos entre classes. Para representar, foram criados uma classe inventário e uma classe loja, junto de diversos objetos. 

O usuário poderá visualizar os itens que estão na classe loja e transferí-los para o próprio inventário. Dentro do inventário, o usuário pode consumir esses itens, descartando-os.
