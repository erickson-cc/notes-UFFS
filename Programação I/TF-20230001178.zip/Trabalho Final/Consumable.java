public interface Consumable{
	void consume();
}	
